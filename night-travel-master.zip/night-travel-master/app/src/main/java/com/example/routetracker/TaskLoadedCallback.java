package com.example.routetracker;


public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
