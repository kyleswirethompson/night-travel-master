package com.example.routetracker;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.IBinder;
import android.telephony.SmsManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


public class L3NotificationsService extends Service {

    public static final String CHANNEL_ID_2 = "Alerts channel";
    DatabaseFunctions myDb;
    String dest;
    String curr;
    long time;


    public void sendSMS() {
        //getting and calculating all the necessary variables to put in the text
        myDb = new DatabaseFunctions(this);
        Cursor res = myDb.getAllUserData();
        res.moveToNext();

        String FirstName = res.getString(1);
        String LastName = res.getString(2);
        String phoneNumber = res.getString(14);

        double multiplier = res.getInt(13);
        double hundred = 100;
        double actualMultiplier = multiplier/hundred;

        double timeAfter = time*0.60*actualMultiplier;
        long timeUntilPolice = TimeUnit.MILLISECONDS.toMinutes((long) timeAfter);

        String textMessage = "This is an automated text sent by RouteTracker from " + FirstName + " " + LastName + ". They might be in danger on their journey to " + dest + ". Their phone is currently at " + curr + ". You should contact them ASAP. A text to the police will be sent if they don't respond in about " + timeUntilPolice + " minutes.";

        //sending the text
        boolean mSMSPermissionGranted = false;
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            mSMSPermissionGranted = true;
        }

        if (mSMSPermissionGranted) {
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> newTextMessage = smsManager.divideMessage(textMessage);
            smsManager.sendMultipartTextMessage(phoneNumber, null, newTextMessage, null, null);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startID) {
        //getting the variables from the intent
        dest = intent.getStringExtra("dest");
        curr = intent.getStringExtra("curr");
        time = intent.getLongExtra("time", 0);

        sendSMS();

        //setting up and displaying the notification
        Intent activityIntent = new Intent(this, LoginActivity.class);
        PendingIntent activityPendingIntent = PendingIntent.getActivity(this, 0, activityIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_2)
                .setSmallIcon(R.drawable.ic_warning)
                .setContentTitle("Level 3 Alert")
                .setContentText("A text has been sent to your emergency contact. Enter the Route Tracker to give yourself more time")
                .setColor(Color.RED)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                //.setFullScreenIntent(contentIntent, true)
                .setContentIntent(activityPendingIntent)
                .setAutoCancel(true)
                .build();
        notification.flags |= Notification.FLAG_INSISTENT;
        notification.flags |= Notification.FLAG_ONGOING_EVENT;

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.notify(2, notification);

        return START_REDELIVER_INTENT;


    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}

